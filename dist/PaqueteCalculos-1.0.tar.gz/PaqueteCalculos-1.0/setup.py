from setuptools import setup

setup(
    name = "PaqueteCalculos",
    version = "1.0",
    description = "Uso de funciones avanzadas de matematicas",
    author = "Bryan Solares",
    author_email = "solares.josue@outlook.com",
    url = "www.makibiway.com",
    packages = ["calculos_video_35","calculos_video_35.avanzados_35"] #sumamente importante
)
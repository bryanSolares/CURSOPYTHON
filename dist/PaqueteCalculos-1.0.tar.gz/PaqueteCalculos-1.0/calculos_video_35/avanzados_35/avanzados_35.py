def potencia(base, exponente):
    print("Resultado potencia: ", base**exponente)

def redondear(num1):
    print("Resultado redondeo: ", round(num1))
def sumar(num1, num2):
    print("Resultado suma: ", num1+num2)

def restar(num1, num2):
    print("Resultado resta: ", num1-num2)

def multiplicar(num1, num2):
    print("Resultado multiplicacion: ", num1*num2)

def dividir(num1, num2):
    try:
        print("Resultado division: ", num1/num2) 
    except:
        print("No se puede divir entre cero")

def potencia(base, exponente):
    print("Resultado potencia: ", base**exponente)

def redondear(num1):
    print("Resultado redondeo: ", round(num1))